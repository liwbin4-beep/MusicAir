# Music Air

Music Air 是一个 Android 12+ 的音乐播放器 UI 工程骨架，采用 Kotlin + Android WebView + 原生 HTML/CSS/JavaScript，并预留 AndroidX Media3 原生音频播放服务。

## 当前包含
- 浅色 / 深色跟随系统
- 首页、发现、搜索、我的四个页面
- 展开式播放器 UI、迷你播放器、演示歌词与播放列表
- QQ 音乐、网易云音乐、酷狗音乐平台筛选 UI
- Media3 播放服务骨架
- Android Studio 可导入工程

## 重要说明
目前没有接入任何第三方解析 API，也没有内置真实歌曲音频。界面中的歌曲、歌词和播放状态均为本地演示数据。请仅接入你有权使用的 API 和授权音频 URL；本项目不提供会员绕过、DRM 解密或受限音源提取功能。

## 构建 APK
1. 使用 Android Studio 打开本目录。
2. 安装 Android SDK 35 和 JDK 17。
3. 等待 Gradle Sync 完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 默认输出到 `app/build/outputs/apk/debug/app-debug.apk`。

命令行构建：`./gradlew assembleDebug`（首次需有 Gradle Wrapper；也可由 Android Studio 自动生成/使用本机 Gradle）。

## 接入真实播放源的下一步
- 定义平台适配器：搜索、歌曲元数据、歌词。
- 另行定义授权音频源提供器，返回可播放 URL、MIME 类型、有效期与来源标识。
- Android 端通过 Media3 `MediaItem` 加载授权 URL。
- 处理 URL 过期、网络错误、用户地区限制和平台授权错误。
- 不要将 API 密钥硬编码在 APK；需要密钥时应由受控后端代理。
