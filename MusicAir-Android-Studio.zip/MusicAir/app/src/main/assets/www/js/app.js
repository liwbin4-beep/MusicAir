const demoSongs=[
 {title:"夏日来信",artist:"Music Air · 演示曲目",platform:"本地演示"},
 {title:"晚风",artist:"Music Air · 演示曲目",platform:"本地演示"},
 {title:"慢慢喜欢你",artist:"Music Air · 演示曲目",platform:"本地演示"},
 {title:"日落大道",artist:"Music Air · 演示曲目",platform:"本地演示"},
 {title:"晴天",artist:"Music Air · 演示曲目",platform:"本地演示"}
];
const app={
 index:0,playing:false,
 init(){
  document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>this.page(b.dataset.page)));
  document.querySelectorAll(".platform").forEach(b=>b.addEventListener("click",()=>{b.parentElement.querySelectorAll(".platform").forEach(x=>x.classList.remove("selected"));b.classList.add("selected")}));
  document.getElementById("query").addEventListener("keydown",e=>{if(e.key==="Enter")this.search()});
  this.renderSongs("recent-list");this.renderSongs("results");
 },
 page(id){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.page===id));},
 renderSongs(id,items=demoSongs){const el=document.getElementById(id);el.innerHTML=items.map((s,i)=>`<div class="song"><div class="song-cover">♫</div><div class="song-meta"><b>${s.title}</b><small>${s.artist} · ${s.platform}</small></div><button onclick="app.select(${i})">▶</button></div>`).join("");},
 select(i){this.index=i%demoSongs.length;this.update();this.toast("已选择演示曲目；接入授权音源后即可播放");},
 update(){const s=demoSongs[this.index];["mini-title","player-title"].forEach(id=>document.getElementById(id).textContent=s.title);["mini-artist","player-artist"].forEach(id=>document.getElementById(id).textContent=s.artist);},
 togglePlay(){this.playing=!this.playing;document.getElementById("big-play").textContent=this.playing?"Ⅱ":"▶";document.querySelector(".mini-play").textContent=this.playing?"Ⅱ":"▶";this.toast(this.playing?"演示播放状态":"已暂停");},
 next(){this.index=(this.index+1)%demoSongs.length;this.update();},prev(){this.index=(this.index+demoSongs.length-1)%demoSongs.length;this.update();},
 openPlayer(){document.getElementById("player").classList.add("open");},closePlayer(){document.getElementById("player").classList.remove("open");},
 openSearch(){this.page("search");document.getElementById("query").focus();},
 search(){const q=document.getElementById("query").value.trim();document.getElementById("result-title").textContent=q?`“${q}” 的演示结果`:"热门推荐";const list=q?demoSongs.filter(s=>(s.title+s.artist).toLowerCase().includes(q.toLowerCase())):demoSongs;this.renderSongs("results",list);if(q&&!list.length)this.toast("演示数据中没有匹配结果");},
 toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>t.classList.remove("show"),1900);}
};
document.addEventListener("DOMContentLoaded",()=>app.init());
