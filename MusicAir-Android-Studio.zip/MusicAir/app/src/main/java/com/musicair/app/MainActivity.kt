package com.musicair.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: android.webkit.WebResourceRequest
                ): Boolean = request.url.scheme != "file" && request.url.scheme != "about"
            }
            addJavascriptInterface(PlayerBridge(), "MusicAir")
            loadUrl("file:///android_asset/www/index.html")
        }
        setContentView(webView)
    }

    inner class PlayerBridge {
        @JavascriptInterface
        fun playDemo() {
            // Playback is intentionally not wired to an unauthorized streaming resolver.
            // Connect a licensed audio URL through PlaybackService when available.
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread {
                android.widget.Toast.makeText(this@MainActivity, message.take(120), android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
